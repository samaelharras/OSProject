import java.util.ArrayList;


public class Memory {
static ArrayList<String> words;
static Process process1;
static Process process2;

public Memory(){
	words = new ArrayList<String>(40);
	for(int i=0; i<40;i++)
		words.add(i, null);
}
public static void printMemory(){
	System.out.println("Memory: " );
	for(int i=0; i<40; i++)
		System.out.println("Word " + i + ": " + words.get(i));
	//System.out.println("Process 1: " + process1);
	//System.out.println("Process 2: " + process2);
}
}
