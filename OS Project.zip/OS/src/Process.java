import java.util.ArrayList;


public class Process{
PCB pcb;
ArrayList<String> instructions;
String a;
String b;
String c;
int arrivalTime;

public Process (PCB pcb, ArrayList<String> instructions, String a, String b, String c, int arrivalTime){
	this.pcb = pcb;
	this.instructions = instructions;
	this.a = a;
	this.b = b;
	this.c = c;
	this.arrivalTime = arrivalTime;
}

public String toString(){
	return "PCB: " + pcb + ", a: " + a + ", b: " + b + ", c: " + c + ", arrival time: " + arrivalTime + ", Instructions: " + instructions;
}

}
