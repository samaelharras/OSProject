import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class CPU {
	int instructionCounter;
	Process currentProcess;
	String currentInstruction;
	ArrayList<String> newProcessName = new ArrayList<String>();
	ArrayList<Integer> newProcessTime = new ArrayList<Integer>();
	

	public CPU(){
		Scheduler scheduler = new Scheduler();
		Memory memory = new Memory();
		Disk disk = new Disk();
		Interpreter interpreter = new Interpreter();
	}
	public void addNewProcess(String programName, int arrival){
		newProcessName.add(programName);
		newProcessTime.add(arrival);
	}
public void createProcess(String programName, int arrival){
	String a = "";
	String b = "";
	String c = "";
	PCB pcb = new PCB(ProcessState.READY, 0, 0, 0);
	int arrivalTime = arrival;
	ArrayList<String> processInstructions = new ArrayList<>();
	try {
	      File myObj = new File(programName);
	      Scanner myReader = new Scanner(myObj);
	      while (myReader.hasNextLine()) {
	        String data = myReader.nextLine();
	        if(data.equals("assign a input")){
	        	processInstructions.add("assign c input");
	        	processInstructions.add("assign a c");
	        }
	        else if(data.equals("assign b input")){
	        	processInstructions.add("assign c input");
	        	processInstructions.add("assign b c");
	        }
	        else if(data.equals("assign b readFile a")){
	        	processInstructions.add("readFile a");
	        	processInstructions.add("assign b c");
	        }
	        else
	        	processInstructions.add(data);
	      }
	      myReader.close();
	    } catch (FileNotFoundException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	Process p = new Process(pcb, processInstructions,a,b,c, arrivalTime);
	Scheduler.readyQueue.add(p);
	addToMemory(p);
	
	}

public void addToMemory(Process p){
	if(Memory.words.get(0)!=null && Memory.words.get(20)!=null){
		Memory.process2.pcb.startWord = 0;
		Memory.process2.pcb.endWord = 0;
		Disk.processes.add(Memory.process2);
		System.out.println("Process " + Memory.process2.pcb.processID + " is swapped from memory to disk");
		Memory.process2 = p;
		p.pcb.startWord = 20;
		p.pcb.endWord = 39;		 
	}
	else if(Memory.words.get(0)==null){
		p.pcb.startWord = 0;
		p.pcb.endWord = 19;
		Memory.process1 = p;	
	}
	else {
		p.pcb.startWord = 20;
		p.pcb.endWord = 39;
		Memory.process2 = p;
	}
	int i=0;
	int sw = p.pcb.startWord;
	 Memory.words.set(sw++, "" +p.pcb.processID);
	 Memory.words.set(sw++, "" +p.pcb.state);
	 Memory.words.set(sw++, "" +p.pcb.programCounter);
	 Memory.words.set(sw++, "" +p.pcb.startWord);
	 Memory.words.set(sw++, "" +p.pcb.endWord);
	 Memory.words.set(sw++, "" +p.a);
	 Memory.words.set(sw++, "" +p.b);
	 Memory.words.set(sw++, "" +p.c);
	 Memory.words.set(sw++, "" +p.arrivalTime);
	 for(i=0; i<p.instructions.size(); i++)
	   Memory.words.set(i+sw, p.instructions.get(i));
	 for(int j=i+sw; j<=p.pcb.endWord;j++)
		 Memory.words.set(j, null);
}

public void execute(){
	while(Scheduler.readyQueue.isEmpty()){
	for(int j=0; j<newProcessTime.size(); j++){
		if(newProcessTime.get(j)==instructionCounter)
			createProcess(newProcessName.get(j), newProcessTime.get(j));
	}
	if(Scheduler.readyQueue.isEmpty())
		instructionCounter++;
	}
	while(!Scheduler.readyQueue.isEmpty()){
	Process p = Scheduler.chooseProcess();
	currentProcess = p;
	//swap from disk to memory
	if(p!=Memory.process1 && p!=Memory.process2){
		Disk.processes.remove(p);
		addToMemory(p);
		System.out.println("Process " + p.pcb.processID + " is swapped from disk to memory");
	}
	for(int i=0; i<Scheduler.timeSlice &&( p.pcb.state.equals(ProcessState.READY) || p.pcb.state.equals(ProcessState.RUNNING)); i++){
		p.pcb.state = ProcessState.RUNNING;
		currentInstruction = p.instructions.get(p.pcb.programCounter);
		System.out.println("Current Process: " + currentProcess.pcb.processID);
		System.out.println("Current Instruction: " + currentInstruction);
		Interpreter.executeNextInstruction(p);
		if(p==Memory.process1){
			Memory.process1.a = p.a;
			Memory.process1.b = p.b;
			Memory.process1.c = p.c;
			Memory.process1.pcb = p.pcb;
			Memory.words.set(1, "" + p.pcb.state);
			Memory.words.set(2, "" +p.pcb.programCounter);
			Memory.words.set(5, p.a);
			Memory.words.set(6, p.b);
			Memory.words.set(7, p.c);
			Memory.words.set(8, "" +p.pcb.programCounter);
		}
		else{
			Memory.process2.a = p.a;
			Memory.process2.b = p.b;
			Memory.process2.c = p.c;
			Memory.process2.pcb = p.pcb;
			Memory.words.set(21, "" + p.pcb.state);
			Memory.words.set(22, "" +p.pcb.programCounter);
			Memory.words.set(25, p.a);
			Memory.words.set(26, p.b);
			Memory.words.set(27, p.c);
		}
		Memory.printMemory();
		instructionCounter++;
		p.pcb.programCounter++;
		

		if(p.pcb.programCounter>=p.instructions.size()){
			System.out.println("Process" + p.pcb.processID + " finished execution");
			System.out.println("Ready Queue: " + Scheduler.readyQueue);
			System.out.println("Blocked queue: " + Scheduler.blockedQueue);
			p.pcb.state = ProcessState.FINISHED;
			if(p==Memory.process1)
				Memory.process1=null;
			else
				Memory.process2 = null;
			for(int j=p.pcb.startWord; j<= p.pcb.endWord; j++)
				Memory.words.set(j, null);
			
				
		}
		for(int j=0; j<newProcessTime.size(); j++){
			if(newProcessTime.get(j)==instructionCounter)
				createProcess(newProcessName.get(j), newProcessTime.get(j));
		}
	}
	if(p.pcb.state.equals(ProcessState.RUNNING)){
	p.pcb.state = ProcessState.READY;
	if(p==Memory.process1)
		Memory.words.set(1, "" +p.pcb.state);
	else
		Memory.words.set(21, "" +p.pcb.state);
	Scheduler.readyQueue.add(p);
	}
	Disk.printDisk();
}
	System.out.println("Execution ended");
}
public static void main(String[] args){
	CPU cpu = new CPU();
	Scheduler.timeSlice = 2;
	cpu.addNewProcess("Program_1.txt", 0);
	cpu.addNewProcess("Program_2.txt", 1);
	cpu.addNewProcess("Program_3.txt", 2);
	cpu.execute();
}
}
