import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;


public class Interpreter {

static Mutex mutexFile;
static Mutex mutexUserInput;
static Mutex mutexUserOutput;
	

public Interpreter(){
	mutexFile = new Mutex();
	mutexUserInput = new Mutex();
	mutexUserOutput = new Mutex();
}
	public static void print(String x){
		System.out.println(x);
	}
	public static String assign(String x, String y){
		if(y.equals("input")){
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a value: ");
		y = sc.nextLine();
		}
		return y;
	}
	public static String writeFile(String x, String y){
		File myFile = new File(x);
		//x = readFile(y);
		try {
			FileWriter myWriter = new FileWriter(x);
			myWriter.write(y);
			myWriter.close();
		} catch (IOException e) {
			System.out.println("An error occurred");
			e.printStackTrace();
		}
		return x;
	}
	public static String readFile(String x){
		String result = "";
		try {
		      File myObj = new File(x);
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        result+=data;
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		return result;
	}
	public static void printFromTo(int x, int y){
		for(int i=x;i<=y;i++)
			System.out.print(i + " ");
		System.out.println();
	}
	public static void executeNextInstruction(Process p){
	ArrayList<String> processInstructions = p.instructions;
	        String data = processInstructions.get(p.pcb.programCounter);
	        switch (data){
	        case "assign c input" : p.c = assign(p.c, "input");break;
	        case "assign a c" : p.a = assign(p.a, p.c);break;
	        case "assign b c" : p.b = assign(p.b, p.c);break;
	        case "printFromTo a b" : printFromTo(Integer.parseInt(p.a),Integer.parseInt(p.b));break;
	        case "writeFile a b" : p.a = writeFile(p.a, p.b);break;
	        case "readFile a" : p.c = readFile(p.a);break;
	        case "semWait file" : Mutex.semWait(mutexFile, p);break;
	        case "semSignal file" : Mutex.semSignal(mutexFile, p);break;
	        case "semWait userInput" : Mutex.semWait(mutexUserInput, p);break;
	        case "semSignal userInput" : Mutex.semSignal(mutexUserInput, p);break;
	        case "semWait userOutput" : Mutex.semWait(mutexUserOutput, p);break;
	        case "semSignal userOutput" : Mutex.semSignal(mutexUserOutput, p);break;
	        case "print b" : print("" + p.b);break;
	        default: break;
	    }
	
	}
}
