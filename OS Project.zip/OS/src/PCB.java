
public class PCB {
static int counter = 0;
int processID ;
ProcessState state;
int programCounter;
int startWord;
int endWord;

public PCB(ProcessState state, int programCounter, int startWord, int endWord){
	this.state = state;
	this.programCounter = programCounter;
	this.startWord = startWord;
	this.endWord = endWord;
	processID = ++counter;
}
public String toString(){
	return "Process ID: " + processID + ", Process state: " + state + 
			", Program counter: " + programCounter + ", Memory boundaries: " + startWord + " to " + endWord;
}
}
