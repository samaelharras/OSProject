import java.util.ArrayList;


public class Scheduler {
static ArrayList<Process> readyQueue ;
static ArrayList<Process> blockedQueue;
static int timeSlice;

public Scheduler(){
	readyQueue = new ArrayList<Process>();
	blockedQueue = new ArrayList<Process>();
}

public static Process chooseProcess(){
	Process p = (Process)readyQueue.remove(0);
	System.out.println("Process " + p.pcb.processID + " is chosen");
	System.out.println("Ready Queue: " + readyQueue);
	System.out.println("Blocked queue: " + blockedQueue);
	p.pcb.state = ProcessState.RUNNING;
	return p;
	
	
}
public static void blockProcess(Process p){
	p.pcb.state = ProcessState.BLOCKED;
	if(p==Memory.process1)
		Memory.words.set(1, "" +p.pcb.state);
	else if(p==Memory.process2)
		Memory.words.set(21, "" +p.pcb.state);
	blockedQueue.add(p);
	readyQueue.remove(p);
	System.out.println("Process" + p.pcb.processID + " is blocked");
	System.out.println("Ready queue: " + readyQueue);
	System.out.println("Blocked queue: " + blockedQueue);
	
}
public static void unblockProcess(Process p){
	blockedQueue.remove(p);
	p.pcb.state = ProcessState.READY;
	if(p==Memory.process1)
		Memory.words.set(1, "" +p.pcb.state);
	else if(p==Memory.process2)
		Memory.words.set(21, "" +p.pcb.state);
	readyQueue.add(p);
}
}
