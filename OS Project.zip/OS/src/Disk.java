import java.util.ArrayList;


public class Disk {
static ArrayList<Process> processes;

public Disk(){
	processes = new ArrayList<Process>();
}

public static void printDisk(){
	System.out.println("Disk: ");
	for(int i=0; i<processes.size();i++)
		System.out.println(processes.get(i));
}
}
