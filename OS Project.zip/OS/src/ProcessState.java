
public enum ProcessState {
NEW, READY, RUNNING, BLOCKED, FINISHED;
}
