
public enum MutexValue {
ZERO, ONE;
}
