import java.util.ArrayList;
import java.util.Queue;


public class Mutex {
MutexValue value = MutexValue.ONE;
ArrayList<Process> queue;
int ownerID;

public Mutex(){
	queue = new ArrayList<Process>();
}
public static void semWait(Mutex m, Process p) {
if (m.value.equals(MutexValue.ONE)) {
m.ownerID = p.pcb.processID;
m.value = MutexValue.ZERO;
} else {
	m.queue.add(p);
	Scheduler.blockProcess(p);
}
}
public static void semSignal(Mutex m, Process p) {
if(m.ownerID == p.pcb.processID) {
if (m.queue.isEmpty())
m.value = MutexValue.ONE;
else {
	Scheduler.unblockProcess((Process)m.queue.get(0));
	m.ownerID =((Process)m.queue.remove(0)) .pcb.processID;
}
}
}
}
